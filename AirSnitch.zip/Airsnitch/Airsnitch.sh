#!/bin/bash

# AirSnitch - By CyberVansh-coder
# Cross-platform WiFi Scanner (Brute-force Coming Soon)

clear

# ASCII Art Banner
echo -e "
   ___      _           _       _       _       
  / _ \__ _| |_ ___  __| | __ _| |_ ___| |__    
 / /_)/ _\` | __/ _ \/ _\` |/ _\` | __/ __| '_ \   
/ ___/ (_| | ||  __/ (_| | (_| | || (__| | | |  
\/     \__,_|\__\___|\__,_|\__,_|\__\___|_| |_| 

            - By CyberVansh-coder
"

# Menu
echo -e "\n[1] Scan Nearby Networks"
echo "[2] Start Brute-force (Coming Soon)"
echo "[3] Exit"
echo -n -e "\nChoose an option: "
read option

# Option handling
case $option in
  1)
    bash modules/scanner.sh
    ;;
  2)
    bash modules/bruteforce.sh
    ;;
  3)
    echo -e "\nExiting AirSnitch. See you soon!"
    exit 0
    ;;
  *)
    echo -e "\nInvalid option. Try again."
    ;;
esac
