#!/bin/bash

clear
echo -e "\n🔍 Scanning WiFi networks..."

# Platform detection
OS="$(uname -s)"

if [[ "$OS" == "Linux" ]]; then
    echo -e "\n📡 Using nmcli (Linux/Kali)"
    nmcli dev wifi list
elif [[ "$OS" == *"_NT-"* ]] || [[ "$OS" == "MINGW"* ]]; then
    echo -e "\n📡 Using netsh (Windows)"
    netsh wlan show networks mode=bssid
elif [[ "$OSTYPE" == "android"* ]]; then
    echo -e "\n📡 Using termux-wifi-scaninfo (Termux)"
    termux-wifi-scaninfo
else
    echo -e "\n❌ Unsupported OS: $OS"
fi

echo -e "\n✅ Scan complete."
