#!/bin/bash

clear
echo -e "\n🔐 Brute-force module is under development..."
echo -e "🚧 Stay tuned for the next update where you'll be able to test WiFi passwords ethically."
